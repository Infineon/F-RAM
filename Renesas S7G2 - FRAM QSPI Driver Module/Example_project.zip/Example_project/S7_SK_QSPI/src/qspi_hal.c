/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
#include <stdio.h>
#include "hal_data.h"
#include "qspi_hal.h"
//#include "bsp_api.h" //gvch

#ifdef SEMI_HOSTING
#ifdef  __GNUC__
extern void initialise_monitor_handles(void);
#endif
#endif

//#define BSP_PRV_QSPI_CLOCK_RATE QSPI_CLK_DIV8 //added gvch
#define LED_GREEN_PIN       IOPORT_PORT_06_PIN_00
#define LED_RED_PIN         IOPORT_PORT_06_PIN_01
#define LED_YELLOW_PIN      IOPORT_PORT_06_PIN_02

#define PUSH_BUTTON_S4      IOPORT_PORT_00_PIN_06

#define BUFFER_LENGTH       (32)
#define CLEAR               (0x00)
#define QSPI_DEVICE_ADDRESS (0x60000000)


/* This application project showcases How to write and read the QSPI F-RAM device.*/
void qspi_hal_module_guide_project_FRAM(void)
{
    /* variable to save return values for error */
    ssp_err_t         err;


    /* buffer to store read and write values */
    uint8_t           writeBuffer[BUFFER_LENGTH];
    uint8_t           readBuffer[BUFFER_LENGTH];
    uint8_t           directreadBuffer[BUFFER_LENGTH];

    /* variables to store result/status */
    bool              in_progress;
    bool              success;
    
    /* variables for IO */
    ioport_port_pin_t led;
    ioport_level_t    pb_sw4_state;

    /* pointer to read directly from ROM */
    const uint8_t *qspi_read_ptr;

#ifdef SEMI_HOSTING
#ifdef __GNUC__                 /* GCC Compiler */
    initialise_monitor_handles();
#endif
#endif

    /* Turn off leds. Leds are connected in sync mode with Micro pins */
    g_ioport.p_api->pinWrite(LED_GREEN_PIN, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(LED_RED_PIN, IOPORT_LEVEL_HIGH);
    g_ioport.p_api->pinWrite(LED_YELLOW_PIN, IOPORT_LEVEL_HIGH);

    /* Fill write buffer with test data. Clear read buffers */
    for (uint8_t i = 0; i < BUFFER_LENGTH; i++)
    {
        writeBuffer[i] =  i;
        readBuffer[i] = CLEAR;
        directreadBuffer[i] = CLEAR;
    }

    /* Open QSPI interface */
    err = g_qspi0.p_api->open(g_qspi0.p_ctrl, g_qspi0.p_cfg);
    if (SSP_SUCCESS != err)
    {
        /* This is a fairly simple error handling - it holds the
         * application execution. In a more realistic scenarios
         * a more robust and complex error handling solution should
         * be provided. */
            #ifdef SEMI_HOSTING
                if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
                {
                    /* Debugger is connected */
                    /* Call this before any calls to printf(); */
                    printf("Could not open QSPI interface, error:%d\n",err);
                }
            #endif
        while (1)
        {
        }
    }


    /* Load write buffer data to QSPI F-RAM memory in SPI mode */
    err = g_qspi0.p_api->WriteSpi(g_qspi0.p_ctrl, (uint8_t *) QSPI_DEVICE_ADDRESS, writeBuffer, BUFFER_LENGTH);
    if (SSP_SUCCESS != err)
    {
        /* This is a fairly simple error handling - it holds the
         * application execution. In a more realistic scenarios
         * a more robust and complex error handling solution should
         * be provided. */
            #ifdef SEMI_HOSTING
                if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
                {
                    /* Debugger is connected */
                    /* Call this before any calls to printf(); */
                    printf("Could not initiate write a data, error:%d\n",err);
                }
            #endif
        while (1)
        {
        }
    }

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf((const char *)"Writing data to QSPI\n");
    }
#endif


    /* Wait until previous operation ends */
    do
    {
        err = g_qspi0.p_api->statusGet(g_qspi0.p_ctrl, &in_progress);
    } while (in_progress);



    if (SSP_SUCCESS != err)
     {
        #ifdef SEMI_HOSTING
            if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
            {
                /* Debugger is connected */
                /* Call this before any calls to printf(); */
                printf("Could not complete write data, error:%d\n",err);
            }
        #endif
        while (1)
            {
            }
     }

    #ifdef SEMI_HOSTING
        if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
        {
            printf((const char *)"Data written\n");
        }
    #endif

    /* Load QSPI F-RAM memory data to read buffer */
    err = g_qspi0.p_api->read(g_qspi0.p_ctrl, (uint8_t *) QSPI_DEVICE_ADDRESS, readBuffer, BUFFER_LENGTH);
    if (SSP_SUCCESS != err)
    {
        /* This is a fairly simple error handling - it holds the
        * application execution. In a more realistic scenarios
        * a more robust and complex error handling solution should
        * be provided. */
          #ifdef SEMI_HOSTING
              if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
              {
                  /* Debugger is connected */
                  /* Call this before any calls to printf(); */
                  printf("Could not complete read operation, error:%d\n",err);
              }
          #endif
        while (1)
        {
        }
    }

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf((const char *)"Reading data from QSPI\n");
    }
#endif


    /* Close QSPI interface */
    err = g_qspi0.p_api->close(g_qspi0.p_ctrl);
    if (SSP_SUCCESS != err)
    {
        /* This is a fairly simple error handling - it holds the
        * application execution. In a more realistic scenarios
        * a more robust and complex error handling solution should
        * be provided. */
          #ifdef SEMI_HOSTING
              if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
              {
                  /* Debugger is connected */
                  /* Call this before any calls to printf(); */
                  printf("Could not close the QSPI instance, error:%d\n",err);
              }
          #endif
        while (1)
        {
        }
    }

    success = true;

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf((const char *)"Comparing data\n");
    }
#endif


    /* Compare write and read buffers */
    for (uint8_t i = 0; i < BUFFER_LENGTH; i++)
    {
        if( writeBuffer[i] == readBuffer[i] )
        {
            success = true;
        }
        else
        {
            success = false;
        }      
    }

    /* If the buffers contain equal data turn the green LED on and the red LED otherwise */
    led = (success ? LED_GREEN_PIN : LED_RED_PIN);

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        if(success)
        {
            printf((const char *)"Data match\n");
        }
        else
        {
            printf((const char *)"Data error\n");
        }
    }
#endif


#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf((const char *)"Press SW4 to continue\n");
    }
#endif

    /* Turn the LED on and off whilst waiting for SW4 to be pressed */
    do
    {
        g_ioport.p_api->pinRead(PUSH_BUTTON_S4, &pb_sw4_state);
        g_ioport.p_api->pinWrite(led, IOPORT_LEVEL_HIGH);
        R_BSP_SoftwareDelay(200, BSP_DELAY_UNITS_MILLISECONDS);

        g_ioport.p_api->pinRead(PUSH_BUTTON_S4, &pb_sw4_state);
        g_ioport.p_api->pinWrite(led, IOPORT_LEVEL_LOW);
        R_BSP_SoftwareDelay(200, BSP_DELAY_UNITS_MILLISECONDS);
    }while (IOPORT_LEVEL_HIGH == pb_sw4_state);

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf((const char *)"Reading QSPI directly as a memory mapped device\n");
    }
#endif

    /* As the QSPI driver has been closed, the QSPI can be read directly,
     * as a memory mapped peripheral */

    /* Turn on LED3 to indicate the second part of the QSPI program */
    g_ioport.p_api->pinWrite(LED_YELLOW_PIN, IOPORT_LEVEL_LOW);

    /* Initialize a pointer to the QSPI device address */
    qspi_read_ptr = (uint8_t*)QSPI_DEVICE_ADDRESS;

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf((const char *)"Reading data from QSPI\n");
    }
#endif

    /* Read 32 bytes directly from the QSPI to directreadBuffer */
    for (uint8_t i = 0; i < BUFFER_LENGTH; i++)
    {
        directreadBuffer[i] = (uint8_t)*qspi_read_ptr;
        qspi_read_ptr++;
    }

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        printf((const char *)"Comparing data\n");
    }
#endif

    /* Compare write and read buffers */
    for (uint8_t i = 0; i < BUFFER_LENGTH; i++)
    {
        if( writeBuffer[i] == directreadBuffer[i] )
        {
            success = true;
        }
        else
        {
            success = false;
        }      
    }
    

    /* If the buffers contain equal data turn the green LED on and the red LED otherwise */
    led = (success ? LED_GREEN_PIN : LED_RED_PIN);

#ifdef SEMI_HOSTING
    if (CoreDebug->DHCSR & CoreDebug_DHCSR_C_DEBUGEN_Msk)
    {
        if(success)
        {
            printf((const char *)"Data match\n");
        }
        else
        {
            printf((const char *)"Data error\n");
        }

        printf((const char *)"Tests completed\n");
    }
#endif

    while (1)
    {
        g_ioport.p_api->pinWrite(led, IOPORT_LEVEL_HIGH);
        R_BSP_SoftwareDelay(200, BSP_DELAY_UNITS_MILLISECONDS);

        g_ioport.p_api->pinWrite(led, IOPORT_LEVEL_LOW);
        R_BSP_SoftwareDelay(200, BSP_DELAY_UNITS_MILLISECONDS);
    }
}
