/* generated main source file - do not edit */
extern void hal_entry(void);
int main(void)
{
    hal_entry ();
    return 0;
}
