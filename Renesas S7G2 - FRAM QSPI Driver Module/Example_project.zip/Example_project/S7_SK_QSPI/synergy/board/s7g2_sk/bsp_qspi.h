/***********************************************************************************************************************
 * Copyright [2015] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 * 
 * This file is part of Renesas SynergyTM Software Package (SSP)
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * This file is subject to a Renesas SSP license agreement. Unless otherwise agreed in an SSP license agreement with
 * Renesas: 1) you may not use, copy, modify, distribute, display, or perform the contents; 2) you may not use any name
 * or mark of Renesas for advertising or publicity purposes or in connection with your use of the contents; 3) RENESAS
 * MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED
 * "AS IS" WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR
 * CONSEQUENTIAL DAMAGES, INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF
 * CONTRACT OR TORT, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents
 * included in this file may be subject to different terms.
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * File Name    : bsp_qspi.h
 * Description  : Configures QSPI bus and device access.
 **********************************************************************************************************************/



/*******************************************************************************************************************//**
 * @ingroup BSP_BOARD_DK2M
 * @defgroup BSP_DK2M_QSPI Board QSPI
 * @brief QSPI configuration setup for this board.
 *
 * This is code specific to the DK2M board.
 *
 * @{
 **********************************************************************************************************************/

#ifndef BSP_QSPI_H_
#define BSP_QSPI_H_

/** Common macro for SSP header files. There is also a corresponding SSP_FOOTER macro at the end of this file. */
SSP_HEADER

/* This QSPI header file requires this be included here. */
#include <stdint.h>
#include <stdbool.h>

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
/***********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/

/* ID and type information for the C15B104QSN Cypress Serial QSPI F-RAM Memory */
#define BSP_PRV_QSPI_MEMORY_CAPACITY 0x50U
#define BSP_PRV_QSPI_MEMORY_TYPE     0x51U
#define BSP_PRV_QSPI_MANUFACTURER_ID1 0x82U
#define BSP_PRV_QSPI_MANUFACTURER_ID2 0x06U
#define BSP_PRV_QSPI_RESERVED_ID1 0x00U
#define BSP_PRV_QSPI_RESERVED_ID2 0x00U
#define BSP_PRV_QSPI_RESERVED_ID3 0x00U
#define BSP_PRV_QSPI_RESERVED_ID4 0x00U

/** Physical address the QSPI device is mapped to */
#define BSP_PRV_QSPI_DEVICE_PHYSICAL_ADDRESS (0x60000000U)

/** When write operation uses multiple data lines, the address is on one line. */
#define QSPI_BYTE_WRITE_ADDRESS_ONE_LINE     (0x1U)

/** When write operation uses single data lines, the data is on 1 lines. */
#define QSPI_BYTE_WRITE_DATA_LINES           (0x1U)

/** data write command. */
#define QSPI_COMMAND_BYTE_WRITE_SPI         (0x02U)

/***********************************************************************************************************************
 * Typedef definitions
 **********************************************************************************************************************/

/** Reference cycle selects. Resultant QSPI clock is PCLKA divided down by the following: (CY15B104QSN Cypress Serial QSPI F-RAM Memory) */
typedef enum e_qspi_clk
{
    /** Reset Operations */
    QSPI_CLK_DIV2,         ///< ie. QSPI CLK runs at 60.00 MHz when PCLKA is set to 120MHz
    QSPI_CLK_DIV3,         ///< ie. QSPI CLK runs at 40.00 MHz when PCLKA is set to 120MHz
    QSPI_CLK_DIV4,         ///< ie. QSPI CLK runs at  30.00 MHz when PCLKA is set to 120MHz
    QSPI_CLK_DIV5,         ///< ie. QSPI CLK runs at  24.00 MHz when PCLKA is set to 120MHz
    QSPI_CLK_DIV6,         ///< ie. QSPI CLK runs at  20.00 MHz when PCLKA is set to 120MHz
    QSPI_CLK_DIV7,         ///< ie. QSPI CLK runs at  17.14 MHz when PCLKA is set to 120MHz
    QSPI_CLK_DIV8,         ///< ie. QSPI CLK runs at  15.00 MHz when PCLKA is set to 120MHz
    QSPI_CLK_DIV9,         ///< ie. QSPI CLK runs at  13.33 MHz when PCLKA is set to 120MHz
    QSPI_CLK_DIV10,        ///< ie. QSPI CLK runs at  12.00 MHz when PCLKA is set to 120MHz
} qspi_clk;


/** Available QSPI read modes for Winbond W25Q64FV quad SPI flash device */
typedef enum e_qspi_readmode
{
    /** Reset Operations */
    QSPI_READMODE_STANDARD,         ///< Standard
    QSPI_READMODE_FAST,             ///< Fast read
    QSPI_READMODE_FAST_DUAL_OUTPUT, ///< Fast Read Dual Output
    QSPI_READMODE_FAST_DUAL_IO,     ///< Fast Read Dual I/O
    QSPI_READMODE_FAST_QUAD_OUTPUT, ///< Fast Read Quad Output
    QSPI_READMODE_FAST_QUAD_IO,     ///< Fast Read Quad I/O
} qspi_readmode;

typedef enum e_qspi_regaddress
{
    /** Reset Operations */
    QSPI_SR1_NVADDRESS        = 0x000000U,         ///< Status Register 1 nonvolatile address
    QSPI_SR1_VADDRESS         = 0x070000U,         ///< Status Register 1 volatile address
    QSPI_SR2_NVADDRESS        = 0x000001U,         ///< Status Register 2 nonvolatile address
    QSPI_SR2_VADDRESS         = 0x070001U,         ///< Status Register 2 volatile address
    QSPI_CR1_NVADDRESS        = 0x000002U,         ///< Config Register 1 nonvolatile address
    QSPI_CR1_VADDRESS         = 0x070002U,         ///< Config Register 1 volatile address
    QSPI_CR2_NVADDRESS        = 0x000003U,         ///< Config Register 2 nonvolatile address
    QSPI_CR2_VADDRESS         = 0x070003U,         ///< Config Register 2 volatile address
    QSPI_CR4_NVADDRESS        = 0x000005U,         ///< Config Register 4 nonvolatile address
    QSPI_CR4_VADDRESS         = 0x070005U,         ///< Config Register 4 volatile address
    QSPI_CR5_NVADDRESS        = 0x000006U,         ///< Config Register 5 nonvolatile address
    QSPI_CR5_VADDRESS         = 0x070006U,         ///< Config Register 5 volatile address
} qspi_regaddress;

/** Available QSPI commands for the Cypress CY15B104QSN quad SPI F-RAM device */
typedef enum e_qspi_command
{
    /** Reset Operations */
    QSPI_COMMAND_RESET_ENABLE              = 0x66U,         ///< Enable reset
    QSPI_COMMAND_RESET_MEMORY              = 0x99U,         ///< Reset memory

    /** Read Operations */
    QSPI_COMMAND_READ                      = 0x03U,         ///< Read memory
    QSPI_COMMAND_FAST_READ                 = 0x0BU,         ///< Read memory
    QSPI_COMMAND_DOR_READ                  = 0x3BU,         ///< Read memory in dual data mode
    QSPI_COMMAND_DIOR_READ                 = 0xBBU,         ///< Read memory in dual address/data mode
    QSPI_COMMAND_QOR_READ                  = 0x6BU,         ///< Read memory in quad data mode
    QSPI_COMMAND_QIOR_READ                 = 0xEBU,         ///< Read memory in quad address/data mode
    QSPI_COMMAND_4BYTE_READ                = 0x00U,         ///<not used>

    /** Write Operations */
    QSPI_COMMAND_WRITE_ENABLE              = 0x06U,         ///< Write Enable
    QSPI_COMMAND_WRITE_DISABLE             = 0x04U,         ///< Write Disable
    QSPI_COMMAND_BYTE_WRITE                = 0x02U,         ///< Write a data
    QSPI_COMMAND_4BYTE_WRITE               = 0x00U,         ///<not used>
    QSPI_COMMAND_DIW_WRITE                 = 0xA2U,         ///< Write a byte in Dual data mode
    QSPI_COMMAND_FAST_WRITE                = 0xDAU,         ///< Program a page in Quad I/O mode
    QSPI_COMMAND_DIOW_WRITE                = 0xA1U,         ///< Write a byte in Dual address/data mode
    QSPI_COMMAND_QIW_WRITE                 = 0x32U,         ///< Write a byte in Quad data mode
    QSPI_COMMAND_QIOW_WRITE                = 0xD2U,         ///< Write a byte in Quad adress/data mode

    /** Register Operations */
    QSPI_COMMAND_READ_STATUS_REGISTER_1    = 0x05U,         ///< Read Status register 1 (S7..S0)
    QSPI_COMMAND_WRITE_STATUS_REGISTER     = 0x01U,         ///< Write Status register 1 (S7..S0)
    QSPI_COMMAND_READ_STATUS_REGISTER_2    = 0x35U,         ///< Read Status register 2 (S15..S8)
    QSPI_COMMAND_READ_CONFIG_REGISTER_1    = 0x35U,         ///< Read Config register 1 (S15..S8)
    QSPI_COMMAND_READ_CONFIG_REGISTER_2    = 0x3FU,         ///< Read Config register 2 (S15..S8)
    QSPI_COMMAND_READ_CONFIG_REGISTER_4    = 0x45U,         ///< Read Config register 4 (S15..S8)
    QSPI_COMMAND_READ_CONFIG_REGISTER_5    = 0x5EU,         ///< Read Config register 5 (S15..S8)
    QSPI_COMMAND_WRITE_ANY_REGISTER        = 0x71U,         ///< Write Any register (S15..S8)
    QSPI_COMMAND_READ_ANY_REGISTER         = 0x65U,         ///< Read Any register (S15..S8)


    QSPI_COMMAND_READ_ID                   = 0x9FU,         ///< Read the chip ID
    QSPI_COMMAND_WRITE_SN                  = 0xC2U,         ///< Write the Serial Number
    QSPI_COMMAND_READ_SN                   = 0xC3U,         ///< Read the Serial Number
    QSPI_COMMAND_READ_UNIQUEID             = 0x4CU,         ///< Read the unique ID



} qspi_command;

/** flag status registers for the CY15B104QSN Cypress quad SPI F-RAM device */
typedef struct st_CY15B104QSN_flag_status_1
{
    /*LDRA_INSPECTED 381 S Anonymous structures and unions are allowed in SSP code. */
    union
    {
        uint8_t    status;
        /*LDRA_INSPECTED 381 S Anonymous structures and unions are allowed in SSP code. */
        struct
        {
            uint8_t wip    : 1;    ///< Erase/Write in progress (busy = 1)
            uint8_t wel     : 1;    ///< Write Latch Enable (Set to 1 after write enable, 0 write disable)
            uint8_t bp      : 3;    ///< Block Protection bits, 1=protected, 0= unprotected
            uint8_t tbprot      : 1;    ///< Top/Bottom block protect Top=0, Bottom=1
            uint8_t rfu     : 1;    ///< Reserved
            uint8_t srwd    : 1;    ///< Status Register write disable. 1 = Locks state of Status & Configuration registers when WP is LOW, 0 = No register protection irrespective of the status of WP pin
         };
    };
} CY15B104QSN_flag_status_1;

typedef struct st_CY15B104QSN_flag_status_2
{
    /*LDRA_INSPECTED 381 S Anonymous structures and unions are allowed in SSP code. */
    union
    {
        uint8_t    status;
        /*LDRA_INSPECTED 381 S Anonymous structures and unions are allowed in SSP code. */
        struct
        {
            uint8_t         : 3;    ///< Reserved
            uint8_t crca    : 1;    ///< 1 = CRC Command aborted, 0 = CRC Command not aborted
            uint8_t crcs    : 1;    ///< 1 = In CRC Suspend Mode, 0 = Not in CRC Suspend Mode
            uint8_t         : 3;    ///< Reserved

         };
    };
} CY15B104QSN_flag_status_2;



typedef struct st_CY15B104QSN_flag_config_1
{
    /*LDRA_INSPECTED 381 S Anonymous structures and unions are allowed in SSP code. */
    union
    {
        uint8_t    config;
        /*LDRA_INSPECTED 381 S Anonymous structures and unions are allowed in SSP code. */
        struct
        {
            uint8_t         : 1;    ///<RFU -Reserved
            uint8_t quad    : 1;    ///< 1 = Quad, 0= Dual or serial
            uint8_t         : 2;    ///<RFU -Reserved
            uint8_t mlc     : 4;    ///< Memory latency code, example
                                    /// 0000 - 0 cycles
                                    /// 0110 - 6 cycles
                                    /// 1111 - 15 cycles

         };
    };
} CY15B104QSN_flag_config_1;

typedef struct st_CY15B104QSN_flag_config_2
{
    /*LDRA_INSPECTED 381 S Anonymous structures and unions are allowed in SSP code. */
    union
    {
        uint8_t    config;
        /*LDRA_INSPECTED 381 S Anonymous structures and unions are allowed in SSP code. */
        struct
        {
            uint8_t         : 4;    ///<RFU -Reserved
            uint8_t dpi     : 1;    ///< 1 = Enable DPI protocol, 0= Enable SPI Protocol, if QPI bit is set to '0'
            uint8_t IO3R    : 1;    ///<1 = I/O3 is used as RESET input when CS is HIGH,  0 = I/O3 has no alternate function
            uint8_t qpi     : 1;    ///< 1 = Enable QPI protocol, 0 = Enable SPI protocol, if DPI bit is set to '0'
            uint8_t         : 1;    ///<RFU -Reserved
         };
    };
} CY15B104QSN_flag_config_2;

typedef struct st_CY15B104QSN_flag_config_4
{
    /*LDRA_INSPECTED 381 S Anonymous structures and unions are allowed in SSP code. */
    union
    {
        uint8_t    config;
        /*LDRA_INSPECTED 381 S Anonymous structures and unions are allowed in SSP code. */
        struct
        {
            uint8_t         : 2;    ///<RFU -Reserved
            uint8_t dpdpor  : 1;    ///< 1 = Deep Power-Down is entered upon completion of POR or Hardware reset (including JEDEC reset) when CS is HIGH. 0 = Standby mode is entered upon completion of Power-up or POR or Hardware reset (including JEDEC reset) when CS is HIGH
            uint8_t         : 2;   ///<<RFU -Reserved
            uint8_t oi     : 1;    ///< output impedance selection, example
                                   /// 000 - 45 ohm
                                  /// 001 - 120 ohm
                                 /// 010 - 90 ohm
                                /// 011 - 60 ohm
                               /// 100 - 45 ohm
                               /// 101 - 30 ohm
                              /// 110 - 20 ohm
                              /// 111 - 20 ohm
         };
    };
} CY15B104QSN_flag_config_4;

typedef struct st_CY15B104QSN_flag_config_5
{
    /*LDRA_INSPECTED 381 S Anonymous structures and unions are allowed in SSP code. */
    union
    {
        uint8_t    config;
        /*LDRA_INSPECTED 381 S Anonymous structures and unions are allowed in SSP code. */
        struct
        {
            uint8_t         : 6;    ///<RFU -Reserved
            uint8_t rlc     : 2;   ///<<Register Latency Code. Selects number of register read latency cycles between 0 and 3 clock cycles for register access.

         };
    };
} CY15B104QSN_flag_config_5;


typedef enum qspi_protocol
{
    QSPI_EXTENDED_SPI_PROTOCOL = 0,
    QSPI_DUAL_SPI_PROTOCOL     = 1,
    QSPI_QUAD_SPI_PROTOCOL     = 2,
} qspi_protocol;

/** characteristics of the flash device */
typedef struct st_qspi_characteristics
{
    uint8_t  memory_capacity;           ///< Memory capacity
    uint8_t  memory_type;               ///< Memory type
    uint8_t  manufacturer_id1;           ///< Manufacturer ID
    uint8_t  manufacturer_id2;           ///< Manufacturer ID
    uint8_t  reserved_id1;           ///< RESERVED ID
    uint8_t  reserved_id2;           ///< RESERVED ID
    uint8_t  reserved_id3;           ///< RESERVED ID
    uint8_t  reserved_id4;           ///< RESERVED ID
} qspi_characteristics;

/***********************************************************************************************************************
 * Exported global variables
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Exported global functions (to be accessed by other files)
 **********************************************************************************************************************/
void bsp_qspi_init (void);

void bsp_qspi_status_get (bool * p_write_in_progress);

void bsp_qspi_config_get (uint8_t  * p_memory_capacity,
                          uint8_t  * p_memory_type,
                          uint8_t  * p_manufacturer_id1,
                          uint8_t  * p_manufacturer_id2,
                          uint8_t  * p_reserved_id1,
                          uint8_t  * p_reserved_id2,
                          uint8_t  * p_reserved_id3,
                          uint8_t  * p_reserved_id4,
                          uint32_t * p_num_address_bytes,
                          uint32_t * p_spi_mode,
                          uint32_t * p_memory_size);


/** Common macro for SSP header files. There is also a corresponding SSP_HEADER macro at the top of this file. */
SSP_FOOTER

#endif /* BSP_QSPI_H_ */
/** @} (end defgroup BSP_DK2M_QSPI) */
