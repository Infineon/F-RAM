/*----------------------------------------------------------------------------
 * Name:    Blinky.c
 * Purpose: LED Flasher for MCB1800
 *----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2004-2014 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------*/

#include "LPC18xx.h"                    /* LPC18xx Definitions                */
#include "Board_LED.h"
#include "lpcspifilib/inc/spifi_fram.h"
#include "string.h"

#define SPIFI_PIN_SET 	(0x02 << 3 | 0x01 << 5 | 0x01 << 6 | 0x01 << 7 | 0x03)
#define USE_SPIFI		1
#define LPC_SPIFI_BASE	0x40003000

uint32_t LEDOn, LEDOff; 


	spifiFRAM_T FRAM;
/*----------------------------------------------------------------------------
  SysTick IRQ Handler
 *----------------------------------------------------------------------------*/
void SysTick_Handler (void) {
  static uint32_t ticks;
  
  switch (ticks++) {
    case  0: LEDOn  = 1; break;
    case  5: LEDOff = 1; break;
    case  9: ticks  = 0; break;
    
    default:
      if (ticks > 10) {
        ticks = 0;
      }
  }
}

void SPIFI_Init(LPC_SPIFI_CHIPHW_T *pSPifi)
{
	
	LPC_SCU->SFSP3_3 = SPIFI_PIN_SET;
	LPC_SCU->SFSP3_4 = SPIFI_PIN_SET;
	LPC_SCU->SFSP3_5 = SPIFI_PIN_SET;
	LPC_SCU->SFSP3_6 = SPIFI_PIN_SET;
	LPC_SCU->SFSP3_7 = SPIFI_PIN_SET;
	LPC_SCU->SFSP3_8 = SPIFI_PIN_SET;
	
	pSPifi->CTRL = SPIFI_CTRL_TO(1000) |
						  SPIFI_CTRL_CSHI(15) |
						  SPIFI_CTRL_RFCLK(1) |
						  SPIFI_CTRL_FBCLK(1);
}
/*----------------------------------------------------------------------------
  Main function
 *----------------------------------------------------------------------------*/
int main (void) {
  int32_t max_num = LED_GetCount() - 1;
  int32_t num = 0;
  int32_t dir = 1;

	uint32_t Addr = 0x00123456;
	uint32_t bytes = 4;
	uint32_t writeBuff[10];
	uint32_t readBuff[10];
		
	FRAM.pSpifi = LPC_SPIFI_BASE;
	writeBuff[0] = 0xA5C30F87;
	
	SystemInit();
  SystemCoreClockUpdate ();                 /* Update system core clock       */  
  SysTick_Config(SystemCoreClock/100);      /* Generate interrupt each 10 ms  */
  LED_Initialize();                         /* LED Initialization             */
	SPIFI_Init((LPC_SPIFI_CHIPHW_T *)LPC_SPIFI_BASE);
	
	//configuring FRAM to a known state
	SpifiFram_config(&FRAM);

	//Setting SPIFI to SPI
	FRAM.fieldform = SPIFI_FIELDFORM_ALL_SERIAL;
	FRAM.frameform = SPIFI_FRAMEFORM_OP_3ADDRESS;
	FRAM.intdlen = 0;
	
	//SPI Write and Read from FRAM
	FRAM_WriteEnable(&FRAM);
	FRAM_Write(&FRAM,Addr,writeBuff,bytes);
	FRAM_WriteDisable(&FRAM);
	FRAM_Read(&FRAM,Addr,readBuff,bytes);
	
	//Enabling QPI Mode
	FRAM_WriteEnable(&FRAM);
	FRAM_SetQPI(&FRAM,1);
	
	//Reading in QPI Mode
	FRAM_Read(&FRAM,Addr,readBuff,bytes);
	
	if(memcmp(writeBuff,&readBuff[1],4))
	{
		LED_On(2);
		LED_Off(3);
	}
	else
	{
		LED_On(3);
		LED_Off(2);
	}
	
	while(1);
}
