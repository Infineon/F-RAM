This directory contains the LPCOpen LPCSPIFI library.

For more details of LPCOpen and the LPCSPIFI Library, visit:
- http://www.nxp.com/pages/:LPC-OPEN-LIBRARIES

See version.txt for details of which version of LPCSPIFI Library
is included within this project.