LPC18/43 SPIFI Generic Flash driver source project
==================================================

LPCXpresso IDE LPC18/43 SPIFI flash driver structured such
that a single generic driver is generated which will 
autodetect the SPIFI part fitted in the target system and
configure itself appropriately.

This means that it is no longer necessary to generate 
individual drivers for specific SPIFI flash devices or 
particular sizes of SPIFI flash devices, making it much easier 
to add support for new SPIFI devices.

Note that the generated driver is only compatible with
LPCXpresso IDE versions later than 7.8.0.

For more information on the use of flash drivers for external
flash, please see the LPCXpresso User Guide chapter on the
"Memory Editor and User Loadable Flash Driver mechanism".
  
Note that this project builds a flash driver with the name
 => LPC18_43_SPIFI_GENERIC.cfx

[
 01 Jun 2016
 - Added support for N25Q32, N25Q64, N25Q256 (partial),
   MT25QL256A, MT25QL512A, MX25V8035F, MX25L12835E.

 22 Oct 2015
 - Added support for N25Q128
 - Init routine now ensures device is in "Single" mode
 
 21 Sep 2015
 - Updated debug build of project to use supplied "Test" 
   linker script and place RAM buffer into second RAM bank. 
   This allows thedebug build to then run on parts with 
   internal flash (and hence smaller amounts of RAM).

 10 Jun 2015
  - Initial version of the generic SPIFI driver project,
    derived from the LPC18_43_SPIFIdriver project (02 Mar 2015)
    supplied with LPCXpresso 7.8.0.
  - Based on LPCOpen 'LPCSPIFI' library v1.0.3 but with 
    additional parts supported (PM25LQ032C, MX25L1606E, 
    W25Q40CV, W25Q128FV) 
]


Supported SPIFI devices
-----------------------
As this flash driver project sits on top of the LPCSPIFI Library,
LPCXpresso flash drivers created using this project  will only be
able to program SPIFI devices supported by the LPCSPIFI Library.

A list of the currently supported SPIFI devices is included below
(with known clone parts listed within {} brackets):

 * 64MB (256KB sector) devices
   ~ S25FL512S

 * 64MB (64KB sector) devices
   ~ MT25QL512A

 * 32MB (256KB sector) devices
   ~ S25FL256S 256k sector

 * 32MB (64KB sector) devices
   ~ S25FL256S 64k sector
   ~ MT25QL256A
   ~ N25Q256

 * 16MB (256KB sector) devices
   ~ S25FL129P 256k Sector {S25FL128S}

 * 16MB (64KB sector) devices
   ~ S25FL129P 64k Sector
   ~ W25Q128FV
   ~ N25Q128
   ~ MX25L12835E

 * 8MB (64KB sector) devices
   ~ S25FL164K
   ~ S25FL064P  
   ~ MX25L6435E
   ~ W25Q64FV
         
 * 4MB (64KB sector) devices
   ~ S25FL032P
   ~ MX25L3235E
   ~ W25Q32FV
   ~ PM25LQ032C  
   
 * 2MB (64KB sector) devices
   ~ S25FL016K {W25Q16DV}
   ~ MX25L1635E
   ~ MX25L1606E  
   
 * 1MB (64KB sector) devices
   ~ W25Q80BV
   ~ MX25L8035E
   ~ MX25V8035F
   
 * 512KB (64KB sector) devices
   ~ W25Q40CV
   
When this flash driver is used, an error will be reported if no 
recognised SPIFI device is found on the target system 

Adding support for other SPIFI devices
--------------------------------------
Support for new parts can be added to the flash driver by updating
the files in the lpcspifilib subdirectory. Please see the LPCSPIFILIB
documentation for more details of how to do this.
 
 
Requirements for building
-------------------------
The use of LPCXpresso IDE v7.80 or later is recommended for 
rebuilding this project.

To build these drivers, you will need to import the 'LPCXFlashDriverLib'
and 'lpc_chip_18xx' library projects provided in the same zip file.

At the time of writing, the 'lpc_chip_18xx' project provided is taken 
from v2.12 release of the LPC18xx version of LPCOpen
- http://www.nxp.com/pages/:LPC-OPEN-LIBRARIES

The project also includes a subdirectory containing the sources and 
headers for the LPCOpen LPCSPIFI Library, which is used to provide 
the actual SPIFI access code. The LPCSPIFI library supplied is 
currently based on the v1.0.3 release. 
- http://www.nxp.com/pages/:LPC-OPEN-LIBRARIES

Also note that the LPC18xx is used as the target MCU for building this
project, as this means that the flash drivers generated should then be 
compatible with both the LPC18 and LPC43 families.
   
Debug / test configuration
--------------------------
In addition to providing the SPIFI_GENERIC build configuration to 
create an actual flash driver, the 'Debug' build configuration can
be used to generate a test version of the flash driver that can be run 
within the LPCXpreso debug environment. This configuration builds
the flash driver wrapped by an interface that mimics the interface
used byLPCXpresso when programming a project executable into flash.

This can be very useful when adding support for a new flash device,
to ensure that basic operation works, before trying out the full 
flash driver.       
        
Note - before starting a debug session for the Debug configuration,
you will need to modify the "Reset Script" setting in the launch 
configuration to reference "LPC18LPC43RamReset.scp".