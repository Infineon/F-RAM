//*****************************************************************************
// flashprogtest.c
// LPCXpresso Flash driver - simple test of flash functions
//*****************************************************************************
//
// Copyright(C) NXP Semiconductors, 2014
// All rights reserved.
//
// Software that is described herein is for illustrative purposes only
// which provides customers with programming information regarding the
// LPC products.  This software is supplied "AS IS" without any warranties of
// any kind, and NXP Semiconductors and its licensor disclaim any and
// all warranties, express or implied, including all implied warranties of
// merchantability, fitness for a particular purpose and non-infringement of
// intellectual property rights.  NXP Semiconductors assumes no responsibility
// or liability for the use of the software, conveys no license or rights under any
// patent, copyright, mask work right, or any other intellectual property rights in
// or to any products. NXP Semiconductors reserves the right to make changes
// in the software without notification. NXP Semiconductors also makes no
// representation or warranty that such application will be suitable for the
// specified use without further testing or modification.
//
// Permission to use, copy, modify, and distribute this software and its
// documentation is hereby granted, under NXP Semiconductors' and its
// licensor's relevant copyrights in the software, without fee, provided that it
// is used in conjunction with NXP Semiconductors microcontrollers.  This
// copyright, permission, and disclaimer notice must appear in all copies of
// this code.
//*****************************************************************************

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#include "lpcx_flash_driver.h"
//#include "spifilib_nvram_api.h"
#include "chip.h"
//#include "testAPI.h"
#include "stopwatch.h"
#include "spifi_fram.h"

#include <cr_section_macros.h>

void testcases(spifiFRAM_T *fram);

uint32_t *writeBuff;

spifiFRAM_T FRAM;

STATIC const PINMUX_GRP_T	spifipinmuxing[] =
{
	{ 0x3, 3, (SCU_PINIO_FAST | SCU_MODE_FUNC3) },

	/* SPIFI CLK */
	{ 0x3, 4, (SCU_PINIO_FAST | SCU_MODE_FUNC3) },

	/* SPIFI D3 */
	{ 0x3, 5, (SCU_PINIO_FAST | SCU_MODE_FUNC3) },

	/* SPIFI D2 */
	{ 0x3, 6, (SCU_PINIO_FAST | SCU_MODE_FUNC3) },

	/* SPIFI D1 */
	{ 0x3, 7, (SCU_PINIO_FAST | SCU_MODE_FUNC3) },

	/* SPIFI D0 */
	{ 0x3, 8, (SCU_PINIO_FAST | SCU_MODE_FUNC3) }	/* SPIFI CS/SSEL */
};

/*
 =======================================================================================================================
 **
 ** SPIFI Initialization
 **		Initialize the SPIFI peripheral to defined maximum frequency.
 **
 ** 	parameters:
 ** 		spifiCtrlAddr	: base address of SPIFI peripheral
 ** 		reset	   		: reset all SPIFI register to default value
 **
 =======================================================================================================================
 */

SPIFI_ERR_T spifi_nvramInit(uint32_t spifiCtrlAddr, uint8_t reset)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	uint32_t	spifiBaseClockRate;
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	/* Setup SPIFI FLASH pin muxing (QUAD) */
	Chip_SCU_SetPinMuxing(spifipinmuxing, sizeof(spifipinmuxing) / sizeof(PINMUX_GRP_T));

	/* SPIFI base clock will be based on the main PLL rate and a divider */
	spifiBaseClockRate = Chip_Clock_GetClockInputHz(CLKIN_MAINPLL);

	/*
	 * Setup SPIFI clock to run around 1Mhz. Use divider E for this, as it allows
	 * higher divider values up to 256 maximum)
	 */
	Chip_Clock_SetDivider(CLK_IDIV_E, CLKIN_MAINPLL, ((spifiBaseClockRate / 12000000) + 1));
	Chip_Clock_SetBaseClock(CLK_BASE_SPIFI, CLKIN_IDIVE, true, false);

	/* Initialize LPCSPIFILIB library, reset the interface */
	return(spifiInit(spifiCtrlAddr, true));
}

#define pSpifiFRAM (LPC_SPIFI_CHIPHW_T *) LPC_SPIFI_BASE;

int main(void)
{

	FRAM.pSpifi = LPC_SPIFI_BASE;

	spifi_nvramInit(LPC_SPIFI_BASE,true);

	printf("\n\rInitialized SPIFI\n\r");

	printf("\n\rConfiguring SPIFI to match with the device\n\r");
	SpifiFram_config(&FRAM);

	FRAM.fieldform = SPIFI_FIELDFORM_ALL_SERIAL;
	FRAM.frameform = SPIFI_FRAMEFORM_OP_3ADDRESS;
	FRAM.intdlen = 0;
	testcases(&FRAM);
	while(1);
}

void testcases(spifiFRAM_T *fram)
{
	uint32_t Addr;
	uint32_t bytes;
//	uint32_t *writeBuff;
	uint32_t *readBuff;

	LPC_SPIFI_CHIPHW_T	*pSpifi;

	Addr = 0x12345678;
	bytes = 4;
	//writeBuff = fram+100;
	*writeBuff = 0xA5C30F78;

	pSpifi = fram->pSpifi;

	FRAM_WriteEnable(fram);
	FRAM_Write(fram,Addr,writeBuff,bytes);
	FRAM_Read(fram,Addr,readBuff,bytes);
	FRAM_WriteDisable(fram);

	FRAM_StatusRegisterWriteDisable(fram,true);
	FRAM_TBPROT(fram,true);
	FRAM_BlockProtect(fram, None);
	while(FRAM_WIP(fram) == Busy);
	FRAM_SetLatency(fram,1);
	FRAM_GetLatency(fram);
	FRAM_SetOuputImpedance(fram,0);
	FRAM_SetDPDPOR(fram,false);
	FRAM_SetRegisterLatency(fram,0);
}
