

typedef enum {
	PASS = 0,
	FAIL
}result_t;


result_t throughputTEST(LPC_SPIFI_CHIPHW_T *,unsigned int);
